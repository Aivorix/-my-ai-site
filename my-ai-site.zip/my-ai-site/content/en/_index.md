---
title: "Welcome"
---
Welcome to my smart site powered by AI.
